#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <math.h>

#ifdef __APPLE__
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "imageloader.h"
#include "md2model.h"

using namespace std;

const float FLOOR_TEXTURE_SIZE = 5.0f; //The size of each floor "tile"

float _angle = 45.0f;

float y = 5.0;

GLuint base;
GLuint day[20];

int rr=1;
int dn=0;
int ff=0;
int c=0;
int cc=0;
float m=-25.0;
float n=0.0;

//Makes the image into a texture, and returns the id of the texture
GLuint loadTexture(Image *image) {
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D,
				 0,
				 GL_RGB,
				 image->width, image->height,
				 0,
				 GL_RGB,
				 GL_UNSIGNED_BYTE,
				 image->pixels);
	return textureId;
}

void initRendering() {
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glShadeModel(GL_SMOOTH);
	if(dn==0){
        glClearColor (0.3, 0.3, 1.0, 0.5);
	}
	//Load the floor texture
	Image* image1 = loadBMP("wve.bmp");
	base = loadTexture(image1);
	delete image1;
	Image* image2 = loadBMP("sunrise.bmp");
	day[0] = loadTexture(image2);
	delete image2;
	Image* image3 = loadBMP("day1.bmp");
	day[1]= loadTexture(image3);
	delete image3;
	Image* image4 = loadBMP("day2.bmp");
	day[2]= loadTexture(image4);
	delete image4;
	Image* image5 = loadBMP("day3.bmp");
	day[3]= loadTexture(image5);
	delete image5;
	Image* image6 = loadBMP("sunset.bmp");
	day[4]= loadTexture(image6);
	delete image6;
	Image* image7 = loadBMP("night.bmp");
	day[5]= loadTexture(image7);
	delete image7;
}

void handleResize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    gluPerspective(45.0, (float)w / (float)h, 1.0, 200.0);
}

void drawTower(){
    glBegin(GL_QUADS);
    //Front
    //glTranslatef(0.0f, -5.4f, 0.0f);
    glColor3f(0.8f, 0.8f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(-1.3f, -5.0f, 1.0f);
	glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(-0.3f, y, -0.15f);
	glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.0f, y, 0.15f);
	glTexCoord2f(2.0f, -2.0f);
	glVertex3f(-1.0f, -5.0f, 1.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front1
    glColor3f(0.7f, 0.8f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(-1.3f, -5.0f, 1.0f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(-0.3f, y, -0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(-0.3f, -5.0f, -0.15f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front2
    glColor3f(0.7f, 0.8f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(-1.0f, -5.0f, 1.3f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.0f, y, 0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.0f, -5.0f, 0.15f);
	glEnd();

	glBegin(GL_QUADS);
	//Front
    glColor3f(0.8f, 0.8f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(1.3f, -5.0f, 1.0f);
	glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.3f, y, -0.15f);
	glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.0f, y, 0.15f);
	glTexCoord2f(2.0f, -2.0f);
	glVertex3f(1.0f, -5.0f, 1.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front1
    glColor3f(0.8f, 0.7f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(1.3f, -5.0f, 1.0f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.3f, -5.0f, -0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.3f, y, -0.15f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front2
    glColor3f(0.8f, 0.7f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(1.0f, -5.0f, 1.3f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.0f, y, 0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.0f, -5.0f, 0.15f);
	glEnd();

	glBegin(GL_QUADS);
	//Front
    glColor3f(0.8f, 0.8f, 0.8f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(0.3f, -5.0f, -1.3f);
	glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.3f, y, -0.15f);
	glTexCoord2f(2.0f, 2.0f);
	glVertex3f(-0.3f, y, -0.15f);
	glTexCoord2f(2.0f, -2.0f);
	glVertex3f(-0.3f, -5.0f, -1.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front1
    glColor3f(0.8f, 0.8f, 0.7f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(0.3f, -5.0f, -1.3f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(0.3f, -5.0f, -0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(0.3f, y, -0.15f);
	glEnd();

	glBegin(GL_TRIANGLES);
	//Front2
    glColor3f(0.8f, 0.8f, 0.7f);
	glNormal3f(0.0f, 0.0f, 1.0f);
	//glTexCoord2f(-2.0f, -2.0f);
	glVertex3f(-0.3f, -5.0f, -1.3f);
	//glTexCoord2f(-2.0f, 2.0f);
	glVertex3f(-0.3f, y, -0.15f);
	//glTexCoord2f(2.0f, 2.0f);
	glVertex3f(-0.3f, -5.0f, -0.15f);
	glEnd();


	glPushMatrix();
    glTranslatef(0.0f, y-0.5, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(),0.7f,0.7f,0.5f,32,3);
    glPopMatrix();

    glEnd();
	glPushMatrix();
    glTranslatef(0.0f, y-0.5, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluDisk(gluNewQuadric(), 0.1f, 0.7f, 32, 1);
    glPopMatrix();
    glEnd();


	glPushMatrix();
	glColor3f(1.0f,0.9f,0.6f);
    glTranslatef(0.0f, y, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(),0.7f,0.9f,0.2f,32,3);
    glPopMatrix();
    glEnd();

    glPushMatrix();
	glColor3f(1.0f,0.9f,0.6f);
    glTranslatef(0.0f, y+0.3, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(),0.9f,0.7f,0.2f,32,3);
    glPopMatrix();
    glEnd();

	glPushMatrix();
    glTranslatef(0.0f, y+0.5, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluDisk(gluNewQuadric(), 0.1f, 0.7f, 32, 1);
    glPopMatrix();
    glEnd();

    glPushMatrix();
    glColor3f(0.5f,0.5f,0.5f);
    glTranslatef(0.0f, y+0.5f, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(), 0.2f, 0.2f,2.0f, 32, 1);
    glPopMatrix();
    glEnd();

    glPushMatrix();
    glColor3f(0.7f,0.9f,0.9f);
    glTranslatef(0.0f, y+2.5f, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(), 0.3f, 0.2f,0.2f, 32, 1);
    glPopMatrix();
    glEnd();

    glPushMatrix();
    glColor3f(0.7f,0.7f,0.7f);
    glTranslatef(0.0f, y+2.7f, 0.0f);
	glRotatef(-122.0f, 1.0f, 1.0f, 1.0f);
    gluCylinder(gluNewQuadric(), 0.09f, 0.01f,2.0f, 32, 1);
    glPopMatrix();
    glEnd();


}

void drawBase(){
    //draw cube
    float xz=2.0f;
	glTranslatef(0.0f, 5.4f, 0.0f);
	glColor3f(0.3f, 0.8f, 0.2f);
	glBegin(GL_QUADS);
	//normal is a vector perpendicular the face we are drawing
	//we need this because if the light source is directly opp to the face then it will be light a lot
	//or if behind it won't be lit at all
	//they have to point outwards, so the back of the face don't get light
    //Front
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-xz, -5.4f, xz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-xz, -5.0f, xz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(xz, -5.0f, xz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(xz, -5.4f, xz);

	//Right
    glNormal3f(1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(xz, -5.4f, xz);
	glTexCoord2f(0.0f, 4.0f);
	glVertex3f(xz, -5.0f, xz);
	glTexCoord2f(4.0f, 4.0f);
	glVertex3f(xz, -5.0f, -xz);
	glTexCoord2f(4.0f, 0.0f);
	glVertex3f(xz, -5.4f, -xz);

	//Back
	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(xz, -5.4f, -xz);
	glTexCoord2f(0.0f, 4.0f);
    glVertex3f(xz, -5.0f, -xz);
	glTexCoord2f(4.0f, 4.0f);
	glVertex3f(-xz, -5.0f, -xz);
	glTexCoord2f(4.0f, 0.0f);
	glVertex3f(-xz, -5.4f, -xz);

	//Left
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-xz, -5.4f, -xz);
	glTexCoord2f(4.0f, 0.0f);
	glVertex3f(-xz, -5.4f, xz);
	glTexCoord2f(4.0f, 4.0f);
	glVertex3f(-xz, -5.0f, xz);
	glTexCoord2f(0.0f, 4.0f);
	glVertex3f(-xz, -5.0f, -xz);

	//top
	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-xz, -5.0f, xz);
    glTexCoord2f(4.0f, 0.0f);
    glVertex3f(xz, -5.0f, xz);
	glTexCoord2f(4.0f, 4.0f);
    glVertex3f(xz, -5.0f, -xz);
    glTexCoord2f(0.0f, 4.0f);
    glVertex3f(-xz, -5.0f, -xz);
}

void drawFloor(){
    glTranslatef(0.0f, -5.4f, 0.0f);
	glColor3f(1.0f, 1.0f, 1.0f);


	glBegin(GL_QUADS);
	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f(200 / FLOOR_TEXTURE_SIZE, 0);
	glVertex3f(-500.0f, 0.0f, -500.0f);
	glTexCoord2f(200 / FLOOR_TEXTURE_SIZE,
				 400 / FLOOR_TEXTURE_SIZE);
	glVertex3f(-500.0f, 0.0f, 500.0f);
	glTexCoord2f(0.0f, 400 / FLOOR_TEXTURE_SIZE);
	glVertex3f(500.0f, 0.0f, 500.0f);
	glTexCoord2f(0.0f, 0);
	glVertex3f(500.0f, 0.0f, -500.0f);

	glEnd();
}

void drawBackground(){
    glPushMatrix();
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, day[dn]);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glBegin(GL_QUADS);
    glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-140.0f, -5.5f, -100.0f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-140.0f, 65.0, -100.0f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(140.0f, 65.0f, -100.0f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(140.0f, -5.5f, -100.0f);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

void drawFog(){
    if(ff==1)
    {
        GLfloat fogcolour[4]= {0.5,0.5,0.5,1.0};
        glFogfv(GL_FOG_COLOR,fogcolour);
        glFogi(GL_FOG_MODE,GL_EXP);
        glFogf(GL_FOG_DENSITY,0.08);
        glHint(GL_FOG_HINT, GL_FASTEST);
        glEnable(GL_FOG);
    }
    if(ff==0)
    {
        glDisable(GL_FOG);
    }
}

void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    glTranslatef(n, 0.0f, m);
	//glRotatef(-_angle, 0.0f, 1.0f, 0.0f);
    if(dn==0){
        GLfloat ambientLight[] = {0.9f, 0.5f, 0.5f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
    }
    else if(dn==1){
        GLfloat ambientLight[] = {0.7f, 0.6f, 0.6f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
    }
    else if(dn==2){
        GLfloat ambientLight[] = {0.6f, 0.6f, 0.7f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
    }
    else if(dn==3){
        GLfloat ambientLight[] = {0.6f, 0.7f, 0.7f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
    }
    else if(dn==4){
        GLfloat ambientLight[] = {0.7f, 0.4f, 0.4f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
    }
    else if(dn==5){
        GLfloat ambientLight[] = {0.2f, 0.2f, 0.2f, 1.0f};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
        GLfloat lightColor[] = {0.7f, 0.3f, 0.3f, 1.0f};
        GLfloat lightPos[] = {-0.2f, 0.3f, -1, 1.0f};
        glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
        glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    }
	GLfloat lightColor[] = {0.7f, 0.7f, 0.7f, 1.0f};
	GLfloat lightPos[] = {-5.2f, 4.3f, 10, 1.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	drawFog();
    drawBackground();

    glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, base);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    drawFloor();
    glRotatef(_angle, 0.0f, 1.0f, 0.0f);
    drawBase();
    glDisable(GL_TEXTURE_2D);
    drawTower();

	glutSwapBuffers();
}

void updateTime(int val){///day night update
    dn++;
    if(dn >= 6)
    {
        dn = 0;
    }
    if(dn==5){
        glutPostRedisplay();
        glutTimerFunc(30000,updateTime,0);
    }
    else{
        glutPostRedisplay();
        glutTimerFunc(5000,updateTime,0);
    }
}

void update(int value) {///tower rotation

	_angle += 0.7f;
	if (_angle > 360) {
		_angle -= 360;
	}
    if(rr==0){
        glutPostRedisplay();
        glutTimerFunc(25, update, 0);
    }
}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
        case 'f':///fog start
            c+=1;
            if(c==1){
                glutPostRedisplay();
                ff=1;
                cc=1;
                break;

            }
            else{///pressing f again ends fog
                glClearColor (0.3, 0.3, 1.0, 0.5);
                glutPostRedisplay();
                ff=0;
                c=0;
            }
            break;
        default:
            break;
	}
}

void my_mouse(int button, int state, int x, int y){
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN)
            rr=0;///tower rotation start
            glutTimerFunc(25, update, 0);
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         if (state == GLUT_DOWN)
			rr=1;///tower rotation off
         break;
      default:
         break;
   }
}

void spe_key(int key, int x, int y){
	switch (key) {
		case GLUT_KEY_UP:///zoom in
                if(rr==1&&m<=50){
                    m+=1;
                    glutPostRedisplay();
                    break;
                }
                break;
        case GLUT_KEY_DOWN:///zoom out
                if(rr==1&&m>=-50){
                    m-=1;
                    glutPostRedisplay();
                    break;
                }
                break;
        case GLUT_KEY_RIGHT:///right move
                if(rr==1&&n<=50){
                    n+=1;
                    glutPostRedisplay();
                    break;
                }
                break;
        case GLUT_KEY_LEFT:///left move
                if(rr==1&&n>=-50){
                    n-=1;
                    glutPostRedisplay();
                    break;
                }
                break;
        default:
            break;
	}
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);

	glutCreateWindow("cgProject");
	initRendering();

	glutDisplayFunc(drawScene);
	glutKeyboardFunc(handleKeypress);
	glutReshapeFunc(handleResize);
	glutTimerFunc(10000, updateTime, 0);
	//glutIdleFunc(run);
    glutMouseFunc(my_mouse);
    glutSpecialFunc(spe_key);
	glutMainLoop();
	return 0;
}









